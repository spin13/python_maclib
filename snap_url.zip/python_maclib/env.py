BASE_DIR = "#{DIR}"
STORAGE_URL = "http://access-storage.kerr-spin.com/"
END_POINT = "http://storage.kerr-spin.com/test.php"
